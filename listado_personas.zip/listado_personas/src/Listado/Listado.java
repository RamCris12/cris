
package Listado;

import javax.swing.JOptionPane;

/**
 *
 * @author Dell
 */
public class Listado {

   
    
    
    public static void main(String[] args) {
       
        
        String nombres [] = new String [10]; 
        int i=0;
        while (i<10){
            
       String nom = JOptionPane.showInputDialog("ingrese el nombre numero :"+ (i+1));
       nombres [i] = nom;
       i++;
    
        }
    JOptionPane.showMessageDialog(null,"Listado de personas \n"
            + "Persona 1:" + nombres [0]+ "\n" 
            + "Persona 2:" + nombres [1]+ "\n" 
            + "Persona 3:" + nombres [2]+ "\n" 
            + "Persona 4:" + nombres [3]+ "\n" 
            + "Persona 5:" + nombres [4]+ "\n" 
            + "Persona 6:" + nombres [5]+ "\n" 
            + "Persona 7:" + nombres [6]+ "\n" 
            + "Persona 8:" + nombres [7]+ "\n" 
            + "Persona 9:" + nombres [8]+ "\n" 
            + "Persona 10:" + nombres [9]+ "\n" 
            +"");
            
           
    }
            


}
