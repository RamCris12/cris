
package pila;

import java.util.Stack;

public class Pila {

    public static void main(String[] args) {
        
        Stack <Persona> pila = new Stack <Persona>();
        Persona persona1 = new Persona();
        persona1.setNombre("Leonardo");
        persona1.setApellidos("Bolaños");
        pila.push(persona1);
        
        Persona persona2 = new Persona();
        persona2.setNombre("Alexander");
        persona2.setApellidos("Jimenez");
        pila.push(persona2);
        
        Persona persona3 = new Persona();
        persona3.setNombre("Nicolas");
        persona3.setApellidos("Peralta");
        pila.push(persona3);
        
        System.out.println(pila);
        pila.pop();
        System.out.println(pila);
    }
    
}
