/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cola;

/**
 *
 * @author Equipo
 */
public class nodo {

   private int elemento;
   private  nodo siguiente;

    public nodo(int elemento, nodo siguiente) {
        this.elemento = elemento;
        this.siguiente = siguiente;
    }

    public int getElemento() {
        return elemento;
    }

    public nodo getSiguiente() {
        return siguiente;
    }

    public void setElemento(int elemento) {
        this.elemento = elemento;
    }

    public void setSiguiente(nodo siguiente) {
        this.siguiente = siguiente;
    }
   
   
    
    
    
}
