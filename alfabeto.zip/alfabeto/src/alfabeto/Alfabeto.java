/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package alfabeto;

/**
 *
 * @author Dell
 */
public class Alfabeto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
        int x,y,s;
        char a=0;
        String q ="";
        String c = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        System.out.println("De \nMayusculas: \n A B C D E F G H I G K L M N O P Q R S T U V W X Y Z \na Minusculas:");
        
        for(int z=0 ;z<c.length();z++){
            y=c.charAt(z);
            x= (int)(y);
            s =x+32;
            a=(char)s;
            q=q+" "+a;
            
            
            
        }
        System.out.println(q);
    }
    

}